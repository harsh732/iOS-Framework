//
//  HMGetSecurityQuestionParsing.m
//  HMAccountManagement
//
//  Created by Vinay Devdikar on 7/6/15.
//  Copyright (c) 2015 Nitor. All rights reserved.
//

#import "HMGetSecurityQuestionParsing.h"

@implementation HMGetSecurityQuestionParsing


-(void)parsedSecurityQuestionWithResponse:(NSString *)_responseString{
    
    NSError *e;
    NSDictionary *JSON = [NSJSONSerialization JSONObjectWithData: [_responseString dataUsingEncoding:NSUTF8StringEncoding]
                                                         options: NSJSONReadingMutableContainers
                                                           error: &e];
    
    if (![[JSON objectForKey:@"securityQuestionAndAnswersListField"] isKindOfClass:[NSNull class]])
        [self parserAllQuestionWith:JSON];
    else
        [_delegate requestForGetAllSecurityQuestionDidFailWith:@"Parsing Error"];
}


-(void)parserAllQuestionWith:(NSDictionary *)_jsonDict{
    
    NSDictionary *sqAnswersDict =[_jsonDict valueForKey:@"securityQuestionAndAnswersListField"];
    
    NSArray *questnsArr;
    
    if (![sqAnswersDict isKindOfClass:[NSNull class]])
        questnsArr =[sqAnswersDict valueForKey:@"securityQuestionsField"];
    else
        [_delegate requestForGetAllSecurityQuestionDidFailWith:@"Parsing Error"];
    
    if ([questnsArr count]!=0) {
        
        HMAccountManagementModel *hmAccountObj =[[HMAccountManagementModel alloc]init];
        
        for (int index=0; index<[questnsArr count]; index++) {
            
            NSDictionary *dict =[questnsArr objectAtIndex:index];
            
            if (![dict isKindOfClass:[NSNull class]]) {
                
                if (index==0) {
                    
                    hmAccountObj.securityQuestionText1=[dict valueForKey:@"textField"];
                    hmAccountObj.securityAnswer1=[dict valueForKey:@"securityAnswerField"];
                    hmAccountObj.securityQuestionPk1=[dict valueForKey:@"securityQuestionPkField"];
                    
                }else{
                    
                    hmAccountObj.securityQuestionText2=[dict valueForKey:@"textField"];
                    hmAccountObj.securityAnswer2=[dict valueForKey:@"securityAnswerField"];
                    hmAccountObj.securityQuestionPk2=[dict valueForKey:@"securityQuestionPkField"];
                }
            }
        }
        
        [_delegate requestForGetAllSecurityQuestionDidFinishWith:hmAccountObj];
        
    }else
        [_delegate requestForGetAllSecurityQuestionDidFailWith:@"Parsing Error"];

}

@end
