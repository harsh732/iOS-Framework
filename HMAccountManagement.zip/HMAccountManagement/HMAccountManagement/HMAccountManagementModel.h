//
//  HMAccountManagementModel.h
//  HMAccountManagement
//
//  Created by Vinay Devdikar on 7/2/15.
//  Copyright (c) 2015 Nitor. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

@interface HMAccountManagementModel : NSManagedObject


@property(nonatomic,strong)NSString *firstName;

@property(nonatomic,strong)NSString *lastName;

@property(nonatomic,strong)NSString *dateOfBirth;

@property(nonatomic,strong)NSString *memberID;

@property(nonatomic,strong)NSString *groupNumber;

@property(nonatomic,strong)NSString *securityAnswer;

@property(nonatomic,strong)NSString *securityQuestionPk;

@property(nonatomic,strong)NSString *newuserName;

@property(nonatomic,strong)NSString *requestType;

@property(nonatomic,strong)NSString *oldPassword;

@property(nonatomic,strong)NSString  *newpassword;

@property(nonatomic,strong)NSString  *securityAnswer1;

@property(nonatomic,strong)NSString  *securityQuestionPk1;

@property(nonatomic,strong)NSString  *securityQuestionText1;

@property(nonatomic,strong)NSString  *securityAnswer2;

@property(nonatomic,strong)NSString  *securityQuestionPk2;

@property(nonatomic,strong)NSString  *securityQuestionText2;

@property(nonatomic,assign)BOOL isAnswerCorrect;

@end
