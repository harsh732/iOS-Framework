//
//  HMGetSecurityQuestionParsing.h
//  HMAccountManagement
//
//  Created by Vinay Devdikar on 7/6/15.
//  Copyright (c) 2015 Nitor. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "HMAccountManagementModel.h"

@protocol HMGetSecurityQuestionDelegate <NSObject>

@required

- (void)requestForGetAllSecurityQuestionDidFinishWith:(HMAccountManagementModel *)_hmAccountModel;

@required

- (void)requestForGetAllSecurityQuestionDidFailWith:(NSString *)_errorString;

@end

@interface HMGetSecurityQuestionParsing : NSObject

@property (nonatomic,strong) id <HMGetSecurityQuestionDelegate> delegate;

-(void)parsedSecurityQuestionWithResponse:(NSString *)_responseString;

@end