//
//  HMAccountManagementModel.m
//  HMAccountManagement
//
//  Created by Vinay Devdikar on 7/2/15.
//  Copyright (c) 2015 Nitor. All rights reserved.
//

#import "HMAccountManagementModel.h"

@implementation HMAccountManagementModel

@synthesize firstName                   =_firstName;

@synthesize lastName                    = _lastName;

@synthesize dateOfBirth                 = _dateOfBirth;

@synthesize memberID                    =  _memberID;

@synthesize groupNumber                 = _groupNumber;

@synthesize securityAnswer              = _securityAnswer;

@synthesize securityQuestionPk          = _securityQuestionPk;

@synthesize newuserName                 = _newuserName;

@synthesize requestType                 =_requestType;

@synthesize newpassword                 = _newpassword;

@synthesize oldPassword                 = _oldPassword;

@synthesize securityAnswer1             = _securityAnswer1;

@synthesize securityQuestionPk1         = _securityQuestionPk1;

@synthesize securityQuestionText1       = _securityQuestionText1;

@synthesize securityAnswer2             =_securityAnswer2;

@synthesize securityQuestionPk2         = _securityQuestionPk2;

@synthesize securityQuestionText2       = _securityQuestionText2;

@synthesize isAnswerCorrect             = _isAnswerCorrect;


-(id)init{
    
    
    _firstName = [[NSString alloc]init];
    _lastName =[[NSString alloc]init];
    _dateOfBirth = [[NSString alloc]init];
    _memberID =[[NSString alloc]init];
    _groupNumber =[[NSString alloc]init];
    _securityQuestionPk=[[NSString alloc]init];
    _securityAnswer =[[NSString alloc]init];
    _newuserName = [[NSString alloc]init];
    _requestType = [[NSString alloc]init];
    _newpassword = [[NSString alloc]init];
    _oldPassword = [[NSString alloc]init];
    _securityAnswer1 = [[NSString alloc]init];
    _securityQuestionPk1 = [[NSString alloc]init];
    _securityQuestionText1 = [[NSString alloc]init];
    _securityAnswer2 = [[NSString alloc]init];
    _securityQuestionPk2 = [[NSString alloc]init];
    _securityQuestionText2 = [[NSString alloc]init];
    
    return self;
}


-(void)dealloc{
    
    _firstName = nil;
    _lastName =nil;
    _dateOfBirth = nil;
    _memberID =nil;
    _groupNumber =nil;
    _securityQuestionPk =nil;
    _securityAnswer =nil;
    _newuserName = nil;
    _requestType=nil;
    _newpassword = nil;
    _oldPassword = nil;
    _securityAnswer1 = nil;
    _securityQuestionPk1 = nil;
    _securityQuestionText1 = nil;
    _securityAnswer2 = nil;
    _securityQuestionPk2 = nil;
    _securityQuestionText2 = nil;
    
}


@end
