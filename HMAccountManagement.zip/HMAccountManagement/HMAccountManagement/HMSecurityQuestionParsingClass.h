//
//  HMSecurityQuestionParsingClass.h
//  HMAccountManagement
//
//  Created by Vinay Devdikar on 7/6/15.
//  Copyright (c) 2015 Nitor. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "HMAccountManagementModel.h"

@protocol HMSecurityQuestionParsingClassDelegate <NSObject>

- (void)requestForSecurityQuestionParseSucessfully:(HMAccountManagementModel *)_hmAccountManagementModel;

- (void)requestForSecurityQuestionParseFailed:(NSString *)_errorString;

@end

@interface HMSecurityQuestionParsingClass : NSObject

@property (nonatomic,strong) id <HMSecurityQuestionParsingClassDelegate> delegate;


-(void)parsedSecurityQuestionWith:(NSString *)_responseString;

@end
