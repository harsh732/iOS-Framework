//
//  HMSecurityQuestionParsingClass.m
//  HMAccountManagement
//
//  Created by Vinay Devdikar on 7/6/15.
//  Copyright (c) 2015 Nitor. All rights reserved.
//

#import "HMSecurityQuestionParsingClass.h"

@implementation HMSecurityQuestionParsingClass


-(void)parsedSecurityQuestionWith:(NSString *)_responseString{
    
    
    NSError *e;
    NSDictionary *JSON = [NSJSONSerialization JSONObjectWithData: [_responseString  dataUsingEncoding:NSUTF8StringEncoding] options: NSJSONReadingMutableContainers error: &e];
    
    
    if (![JSON isKindOfClass:[NSNull class]]) {
        
        [self DataParsingSucessFullyWithDitct:JSON];
        
    }else{
        
        [self UnableToParseTheData];
    }
    
}

-(void)DataParsingSucessFullyWithDitct:(NSDictionary *)_JsonDict{
    
    NSArray *arr = (NSArray *)[_JsonDict valueForKey:@"securityQuestionsField"];
    
    if ([arr count]!=0) {
        
        HMAccountManagementModel *securityObj=[[HMAccountManagementModel alloc]init];
        
        for (int i=0; i<[arr count]; i++) {
            
            NSDictionary *dict = (NSDictionary *)[arr objectAtIndex:i];
            
            if (![[dict valueForKey:@"textField"] isKindOfClass:[NSNull class]])
                securityObj.securityQuestionText1=[dict valueForKey:@"textField"];
            
            if (![[dict valueForKey:@"securityQuestionPkField"] isKindOfClass:[NSNull class]])
                securityObj.securityQuestionPk1=[dict valueForKey:@"securityQuestionPkField"];
            
        }
        
        [_delegate requestForSecurityQuestionParseSucessfully:securityObj];
        
        
    }else{
        
         [_delegate requestForSecurityQuestionParseFailed:@"parseFailed"];
    }
    
    
}


-(void)UnableToParseTheData{
    
    [_delegate requestForSecurityQuestionParseFailed:@"parseFailed"];
}



@end
