//
//  HMAccountManagement.h
//  HMAccountManagement
//
//  Created by Vinay Devdikar on 7/2/15.
//  Copyright (c) 2015 Nitor. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "HMAccountManagementModel.h"

@protocol HMAccountManagementDelegate <NSObject>

@optional


- (void)requestForSecurityQuestionDidFinishWithRespone:(HMAccountManagementModel *)_hmAccountModel;

@optional

- (void)requestForSecurityQuestionDidFailWithError:(NSString *)_errorString;

@optional

- (void)requestForValidateSecurityAnswerDidFinishWithRespone:(HMAccountManagementModel *)_hmAccountModel;

@optional

- (void)requestForValidateSecurityAnswerDidFailWithError:(NSString *)_errorString;

@optional

- (void)requestForUpdateUserNameDidFinishWithRespone:(HMAccountManagementModel *)_hmAccountModel;

@optional

- (void)requestForUpdateUserNameDidFailWithError:(NSString *)_errorString;

@optional

- (void)requestForUpdatePasswordDidFinishWithRespone:(HMAccountManagementModel *)_hmAccountModel;

@optional

- (void)requestForUpdatePasswordDidFailWithError:(NSString *)_errorString;

@optional

- (void)requestForupdateSecurityQuestionDidFinishWithRespone:(HMAccountManagementModel *)_hmAccountModel;

@optional

- (void)requestForupdateSecurityQuestionDidFailWithError:(NSString *)_errorString;

@optional

-(void)requestForGetAllSecurityQuestionAnswerDidFinishWithRespone:(HMAccountManagementModel *)_hmAccountModel;

@optional

-(void)requestForGetAllSecurityQuestionAnswerDidFailWithError:(NSString *)_errorString;


@end


@interface HMAccountManagement : NSObject


@property (nonatomic,strong)id <HMAccountManagementDelegate> delegate;

// requestForSecurityQuestion Method use to get the security question of perticular user which he set at the time of registration.

- (void)requestForSecurityQuestionWithModel:(HMAccountManagementModel *)_hmAccountModel;

// Validate security question this method use for checking the user security answer which he enter at the time of registration.

- (void)requestForValidateSecurityAnswerWithModel:(HMAccountManagementModel *)_hmAccountModel;

// update username this method is use for updating the user name.

- (void)requestForUpdateUserNameWithModel:(HMAccountManagementModel *)_hmAccountModel;

// update the password is use for the updating the password.

- (void)requestForUpdatePasswordWithModel:(HMAccountManagementModel *)_hmAccountModel;

// update the security question which update the security question and answer.

- (void)requestForupdateSecurityQuestionWithModel:(HMAccountManagementModel *)_hmAccountModel;

// this method returns the security question and answers which he set at the time of registration.

- (void)requestForGetAllSecurityQuestionAnswer;

@end
