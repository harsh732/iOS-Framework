//
//  HMAccountManagement.m
//  HMAccountManagement
//
//  Created by Vinay Devdikar on 7/2/15.
//  Copyright (c) 2015 Nitor. All rights reserved.
//

#import "HMAccountManagement.h"

#import "HMSecurityQuestionParsingClass.h"
#import "HMGetSecurityQuestionParsing.h"



@interface HMAccountManagement () <NSURLConnectionDataDelegate,NSURLConnectionDelegate,HMSecurityQuestionParsingClassDelegate,HMGetSecurityQuestionDelegate>{
    
    NSMutableData *serverdata;
    
    NSMutableURLRequest *request;
    
    int statusCode,responseValue;
    
}

@end

@implementation HMAccountManagement

-(id)init{
    
    
    return self;
}


#pragma mark - Create Request

-(void)requestForSecurityQuestionWithModel:(HMAccountManagementModel *)_hmAccountModel{
    
    responseValue=0;
    NSString *params = [NSString stringWithFormat:@"{\"FirstName\":\"%@\",\"LastName\":\"%@\",\"DateOfBirth\":\"%@\",\"MemberId\":\"%@\",\"GroupNumber\":\"%@\",%@,%@}",_hmAccountModel.firstName,_hmAccountModel.lastName,_hmAccountModel.dateOfBirth,_hmAccountModel.memberID,_hmAccountModel.groupNumber,[self CreateuserString],[self ApplicationStr]];
    NSString *strService = [NSString stringWithFormat:@"AccountRecovery/SecurityQuestionForUsername?requestObj=%@",params];
    NSString *getBaseurl =[NSString stringWithFormat:@"%@%@",[self GetServerEndPoints],strService];
    NSLog(@"getBaseurl %@",getBaseurl);
    request=[[NSMutableURLRequest alloc]initWithURL:[self baseURLWitUrl:getBaseurl]];
    NSString *acestoken=[NSString stringWithFormat:@"Bearer %@",[self GetAcessToken]];
    [request addValue:acestoken forHTTPHeaderField:@"Authorization"];
    [request setValue:@"application/json" forHTTPHeaderField: @"Content-Type"];
    [request setHTTPMethod:@"GET"];
    NSURLConnection *connect = [[NSURLConnection alloc]initWithRequest:request delegate:self];
    if (connect) {
        serverdata =[[NSMutableData alloc]init];
    }
    
}

-(void)requestForValidateSecurityAnswerWithModel:(HMAccountManagementModel *)_hmAccountModel{
    
    responseValue=1;
    NSString *params = [NSString stringWithFormat:@"{%@,%@,\"SecurityAnswer\":\"%@\",\"SecurityQuestionPk\":\"%@\",\"MemberPK\":\"%@\"}",[self CreateuserString],[self ApplicationStr],_hmAccountModel.securityAnswer,_hmAccountModel.securityQuestionPk,[self GetmemberPk]];
    NSString *strService = [NSString stringWithFormat:@"ManageForm/ValidateAnswer?requestObj=%@",params];
    NSString *getBaseurl =[NSString stringWithFormat:@"%@%@",[self GetServerEndPoints],strService];
     NSLog(@"getBaseurl %@",getBaseurl);
    request=[[NSMutableURLRequest alloc]initWithURL:[self baseURLWitUrl:getBaseurl]];
    NSString *acestoken=[NSString stringWithFormat:@"Bearer %@",[self GetAcessToken]];
    [request addValue:acestoken forHTTPHeaderField:@"Authorization"];
    [request setValue:@"application/json" forHTTPHeaderField: @"Content-Type"];
    [request setHTTPMethod:@"GET"];
    NSURLConnection *connect = [[NSURLConnection alloc]initWithRequest:request delegate:self];
    if (connect) {
        serverdata =[[NSMutableData alloc]init];
    }
    
}


-(void)requestForUpdateUserNameWithModel:(HMAccountManagementModel *)_hmAccountModel{
    
    responseValue=2;
    NSString *params = [NSString stringWithFormat:@"{%@,%@,\"NewUsername\":\"%@\",\"StrRequestType\":\"%@\",\"MemberPK\":\"%@\"}",[self CreateuserString],[self ApplicationStr],_hmAccountModel.newuserName,_hmAccountModel.requestType,[self GetmemberPk]];
    NSString *strService = [NSString stringWithFormat:@"ManageForm/UpdateMember?requestObj=%@",params];
    NSString *getBaseurl =[NSString stringWithFormat:@"%@%@",[self GetServerEndPoints],strService];
     NSLog(@"getBaseurl %@",getBaseurl);
    request=[[NSMutableURLRequest alloc]initWithURL:[self baseURLWitUrl:getBaseurl]];
    NSString *acestoken=[NSString stringWithFormat:@"Bearer %@",[self GetAcessToken]];
    [request addValue:acestoken forHTTPHeaderField:@"Authorization"];
    [request setValue:@"application/json" forHTTPHeaderField: @"Content-Type"];
    [request setHTTPMethod:@"GET"];
    NSURLConnection *connect = [[NSURLConnection alloc]initWithRequest:request delegate:self];
    if (connect) {
        serverdata =[[NSMutableData alloc]init];
    }
}


-(void)requestForUpdatePasswordWithModel:(HMAccountManagementModel *)_hmAccountModel{
    
    
    responseValue=3;
    NSString *params = [NSString stringWithFormat:@"{%@,%@,\"StrOldPassword\":\"%@\",\"StrNewPassword\":\"%@\",\"MemberPK\":\"%@\",\"StrRequestType\":\"%@\"}",[self CreateuserString],[self ApplicationStr],_hmAccountModel.oldPassword,_hmAccountModel.newpassword,[self GetmemberPk],_hmAccountModel.requestType];
    NSString *strService = [NSString stringWithFormat:@"ManageForm/UpdateMember?requestObj=%@",params];
    NSString *getBaseurl =[NSString stringWithFormat:@"%@%@",[self GetServerEndPoints],strService];
     NSLog(@"getBaseurl %@",getBaseurl);
    request=[[NSMutableURLRequest alloc]initWithURL:[self baseURLWitUrl:getBaseurl]];
    NSString *acestoken=[NSString stringWithFormat:@"Bearer %@",[self GetAcessToken]];
    [request addValue:acestoken forHTTPHeaderField:@"Authorization"];
    [request setValue:@"application/json" forHTTPHeaderField: @"Content-Type"];
    [request setHTTPMethod:@"GET"];
    NSURLConnection *connect = [[NSURLConnection alloc]initWithRequest:request delegate:self];
    if (connect) {
        serverdata =[[NSMutableData alloc]init];
    }

    
}

-(void)requestForGetAllSecurityQuestionAnswer{
    
    responseValue=4;
    NSString *params = [NSString stringWithFormat:@"{%@,%@,\"MemberPK\":\"%@\"}",[self CreateuserString],[self ApplicationStr],[self GetmemberPk]];
    NSString *strService = [NSString stringWithFormat:@"ManageForm/GetMemberSecurityQuestionsAndAnswers?requestObj=%@",params];
    NSString *getBaseurl =[NSString stringWithFormat:@"%@%@",[self GetServerEndPoints],strService];
    request=[[NSMutableURLRequest alloc]initWithURL:[self baseURLWitUrl:getBaseurl]];
    NSString *acestoken=[NSString stringWithFormat:@"Bearer %@",[self GetAcessToken]];
    [request addValue:acestoken forHTTPHeaderField:@"Authorization"];
    [request setValue:@"application/json" forHTTPHeaderField: @"Content-Type"];
    [request setHTTPMethod:@"GET"];
    NSURLConnection *connect = [[NSURLConnection alloc]initWithRequest:request delegate:self];
    if (connect) {
        serverdata =[[NSMutableData alloc]init];
    }

    
}

-(void)requestForupdateSecurityQuestionWithModel:(HMAccountManagementModel *)_hmAccountModel{
    
    responseValue=5;
    NSString *params = [NSString stringWithFormat:@"{%@,%@,\"MemberPK\":\"%@\",\"SecurityAnswer1\":\"%@\",\"SecurityQuestionPk1\":\"%@\",\"SecurityQuestionText1\":\"%@\",\"SecurityAnswer2\":\"%@\",\"SecurityQuestionPk2\":\"%@\",\"SecurityQuestionText2\":\"%@\",\"StrRequestType\":\"%@\"}",[self CreateuserString],[self ApplicationStr],[self GetmemberPk],_hmAccountModel.securityAnswer1,_hmAccountModel.securityQuestionPk1,_hmAccountModel.securityQuestionText1,_hmAccountModel.securityAnswer2,_hmAccountModel.securityQuestionPk2,_hmAccountModel.securityQuestionText2,_hmAccountModel.requestType];
    NSString *strService = [NSString stringWithFormat:@"ManageForm/UpdateMember?requestObj=%@",params];
    NSString *getBaseurl =[NSString stringWithFormat:@"%@%@",[self GetServerEndPoints],strService];
    request=[[NSMutableURLRequest alloc]initWithURL:[self baseURLWitUrl:getBaseurl]];
    NSString *acestoken=[NSString stringWithFormat:@"Bearer %@",[self GetAcessToken]];
    [request addValue:acestoken forHTTPHeaderField:@"Authorization"];
    [request setValue:@"application/json" forHTTPHeaderField: @"Content-Type"];
    [request setHTTPMethod:@"GET"];
    NSURLConnection *connect = [[NSURLConnection alloc]initWithRequest:request delegate:self];
    if (connect) {
        serverdata =[[NSMutableData alloc]init];
    }
    
    
}


#pragma mark - Get Connection EndPoints

-(NSURL *)baseURLWitUrl:(NSString *)_urlString {
    
    NSString *escapedUrlString = [_urlString stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    NSURL *url = [[NSURL alloc] initWithString:escapedUrlString];
    return url;
}


-(NSString *)GetServerEndPoints{
    
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    NSString *endPoint = [defaults objectForKey:@"environment"];
    NSString *server;
    NSString *path = [self getDocumentDirectoryPathForEndpoints];
    NSDictionary *dict = [NSDictionary dictionaryWithContentsOfFile: path];
    
    switch ([endPoint integerValue]) {
        case 1:
            server = (NSString *)[dict objectForKey: @"DEVApiEoints"];
            break;
        case 2:
            server = (NSString *)[dict objectForKey: @"QAapiEndpoints"];
            break;
        case 3:
            server = (NSString *)[dict objectForKey: @"UATapiEndpoints"];
            break;
        case 4:
            server = (NSString *)[dict objectForKey: @"PROapiEndpoints"];
            break;
        case 5:
            server = (NSString *)[dict objectForKey: @"STGapiEndpoints"];
            break;
        default:
            server = (NSString *)[dict objectForKey: @"PROapiEndpoints"];
            break;
    }
    
    return server;
    
}


#pragma mark - Get value from plist

-(NSString *)getDocumentDirectoryPath{
    
    NSArray *pathsArray = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask,YES);
    NSString *doumentDirectoryPath=[pathsArray objectAtIndex:0];
    NSString *destinationPath= [doumentDirectoryPath stringByAppendingPathComponent:@"constant.plist"];
    return destinationPath;
}


-(NSString *)getDocumentDirectoryPathForEndpoints{
    
    NSArray *pathsArray = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask,YES);
    NSString *doumentDirectoryPath=[pathsArray objectAtIndex:0];
    NSString *destinationPath= [doumentDirectoryPath stringByAppendingPathComponent:@"enpoints.plist"];
    return destinationPath;
}


-(NSString *)CreateuserString{
    
    NSString *userString = [NSString stringWithFormat:@"\"User\":{\"UserPK\":\"%@\",\"UserName\":\"%@\",\"Uuid\":\"%@\"}",[self GetUserpk],[self GetUserName],[self GetuuID]];
    return userString;
}


-(NSString *)ApplicationStr{
    
    NSString *ApplicationStr =[NSString stringWithFormat:@"\"Application\":{\"CustomerId\":\"%@\",\"CustomerName\":\"%@\",\"ProgramName\":\"%@\"}",[self getCustomerId],[self getCustomerNameStr],[self getProgramNameStr]];
    
    return ApplicationStr;
}

#pragma mark - Customer Details

-(NSString *)getCustomerId{
    
    NSString *path = [self getDocumentDirectoryPathForEndpoints];
    NSDictionary *dict = [NSDictionary dictionaryWithContentsOfFile: path];
    NSString *customerIdStr = (NSString *)[dict objectForKey: @"CustomerId"];
    return customerIdStr;
}

-(NSString *)getResponseVersion{
    
    NSString *path = [self getDocumentDirectoryPathForEndpoints];
    NSDictionary *dict = [NSDictionary dictionaryWithContentsOfFile: path];
    NSString *responseVersionStr = (NSString *)[dict objectForKey: @"ResponseVersion"];
    return responseVersionStr;
}

-(NSString *)getCustomerNameStr{
    
    NSString *path = [self getDocumentDirectoryPathForEndpoints];
    NSDictionary *dict = [NSDictionary dictionaryWithContentsOfFile: path];
    NSString *customerNameStr = (NSString *)[dict objectForKey: @"CustomerName"];
    return customerNameStr;
}


-(NSString *)getProgramNameStr{
    
    NSString *path = [self getDocumentDirectoryPathForEndpoints];
    NSDictionary *dict = [NSDictionary dictionaryWithContentsOfFile: path];
    NSString *programNameStr = (NSString *)[dict objectForKey: @"ProgramName"];
    return programNameStr;
}

#pragma mark - User Details

-(NSString *)GetAcessToken{
    
    NSString *path = [self getDocumentDirectoryPath];
    NSDictionary *dict = [NSDictionary dictionaryWithContentsOfFile: path];
    NSString *acessToken = (NSString *)[dict objectForKey: @"acessToken"];
    return acessToken;
}

-(NSString *)GetUserName{
    
    NSString *path = [self getDocumentDirectoryPath];
    NSDictionary *dict = [NSDictionary dictionaryWithContentsOfFile: path];
    NSString *acessToken = (NSString *)[dict objectForKey: @"userName"];
    return acessToken;
}

-(NSString *)GetUserpk{
    
    NSString *path = [self getDocumentDirectoryPath];
    NSDictionary *dict = [NSDictionary dictionaryWithContentsOfFile: path];
    NSString *acessToken = (NSString *)[dict objectForKey: @"userPk"];
    return acessToken;
}


-(NSString *)GetuuID{
    
    NSString *path = [self getDocumentDirectoryPath];
    NSDictionary *dict = [NSDictionary dictionaryWithContentsOfFile: path];
    NSString *acessToken = (NSString *)[dict objectForKey: @"uuID"];
    return acessToken;
}


-(NSString *)GetmemberPk{
    
    NSString *path = [self getDocumentDirectoryPath];
    NSDictionary *dict = [NSDictionary dictionaryWithContentsOfFile: path];
    NSString *memberPk = (NSString *)[dict objectForKey: @"memberPk"];
    return memberPk;
}


-(NSString *)getResoponeVersionStr{
    
    NSString *path = [self getDocumentDirectoryPath];
    NSDictionary *dict = [NSDictionary dictionaryWithContentsOfFile: path];
    NSString *responeVersionStr = (NSString *)[dict objectForKey: @"responeVersion"];
    return responeVersionStr;
}

#pragma mark - Connection Delegate

-(void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)urlResponse {
    
    NSHTTPURLResponse* httpResponse = (NSHTTPURLResponse*)urlResponse;
    int code = (int)[httpResponse statusCode];
    statusCode=code;
    [serverdata setLength: 0];
    
}

-(void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data{
    [serverdata appendData:data];
}

-(void)connectionDidFinishLoading:(NSURLConnection *)connection{
    
    if (![serverdata isKindOfClass:[NSNull class]] && serverdata !=nil && 200 == statusCode) {
        
        NSLog(@"Got Response");
        NSString *response=[[NSString alloc]initWithData:serverdata encoding:NSUTF8StringEncoding];
        [self parseSucessResponseAspertheValue:response];
        
    }else{
        
        NSString *response=[[NSString alloc]initWithData:serverdata encoding:NSUTF8StringEncoding];
        [self parseFailurResponseAspertheValue:response];
    }
}

-(void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error{
    
    [self parseFailurResponseAspertheValue:error.description];

}

#pragma mark - Parsing Methods

-(void)parseSucessResponseAspertheValue:(NSString *)_response{
    
    
    switch (responseValue) {
            
        case 0:{
            
            HMSecurityQuestionParsingClass *hmQuestion =[[HMSecurityQuestionParsingClass alloc]init];
            hmQuestion.delegate=self;
            [hmQuestion parsedSecurityQuestionWith:_response];
        
        }break;
        case 1:
            [self validateResponseWith:_response];
            break;
        case 2:
             [self validateResponseWith:_response];
            break;
        case 3:
             [self validateResponseWith:_response];
            break;
        case 4:{
            
            HMGetSecurityQuestionParsing *hmQuestion =[[HMGetSecurityQuestionParsing alloc]init];
            hmQuestion.delegate =self;
            [hmQuestion parsedSecurityQuestionWithResponse:_response];
            
            }break;
        case 5:
            [self validateResponseWith:_response];
            break;
        default:
            break;
    }
    
    
    
}

-(void)parseFailurResponseAspertheValue:(NSString *)_response{
    
    
    switch (responseValue) {
            
        case 0:
            [_delegate requestForSecurityQuestionDidFailWithError:_response];
            break;
        case 1:
            [_delegate requestForValidateSecurityAnswerDidFailWithError:_response];
            break;
        case 2:
           [_delegate requestForUpdateUserNameDidFailWithError:_response];
            break;
        case 3:
            [_delegate requestForUpdatePasswordDidFailWithError:_response];
            break;
        case 4:
            [_delegate requestForGetAllSecurityQuestionAnswerDidFailWithError:_response];
            break;
        case 5:
             [_delegate requestForupdateSecurityQuestionDidFailWithError:_response];
            break;
        default:
            break;
    }
    
    
    
}


-(void)validateResponseWith:(NSString *)_responseString{
    
    NSLog(@"Validation %@",_responseString);
    
    HMAccountManagementModel *model =[[HMAccountManagementModel alloc]init];
    
    if ([_responseString isEqualToString:@"true"] ){
        model.isAnswerCorrect=YES;
        [self callSucessDelegate:model];
        
    }else if ( [_responseString length]>5 || ![_responseString isEqualToString:@"false"]){
        model.isAnswerCorrect=YES;
        [self callSucessDelegate:model];
        
    }else
        [self parseFailurResponseAspertheValue:_responseString];
    
    
    
}


-(void)callSucessDelegate:(HMAccountManagementModel *)_hmAccountObj{
    
    NSLog(@"%d",responseValue);
    
    switch (responseValue) {
        
        case 1:
            [_delegate requestForValidateSecurityAnswerDidFinishWithRespone:_hmAccountObj];
            break;
        case 2:
            [_delegate requestForUpdateUserNameDidFinishWithRespone:_hmAccountObj];
            break;
        case 3:
            [_delegate requestForUpdatePasswordDidFinishWithRespone:_hmAccountObj];
            break;
        case 4:
            
            break;
        case 5:
             [_delegate requestForupdateSecurityQuestionDidFinishWithRespone:_hmAccountObj];
            break;
            
        default:
            break;
    }
    
    
}

#pragma mark - Security Question Parsing Class Delegate

-(void)requestForSecurityQuestionParseSucessfully:(HMAccountManagementModel *)_hmAccountManagementModel{
    
    [_delegate requestForSecurityQuestionDidFinishWithRespone:_hmAccountManagementModel];
    
}

- (void)requestForSecurityQuestionParseFailed:(NSString *)_errorString{
    
    [_delegate requestForSecurityQuestionDidFailWithError:_errorString];
    
}

#pragma mark - Get All Security Question Delegate


-(void)requestForGetAllSecurityQuestionDidFinishWith:(HMAccountManagementModel *)_hmAccountModel{
    
    [_delegate requestForGetAllSecurityQuestionAnswerDidFinishWithRespone:_hmAccountModel];
    
}

-(void)requestForGetAllSecurityQuestionDidFailWith:(NSString *)_errorString{
    
    [_delegate requestForGetAllSecurityQuestionAnswerDidFailWithError:_errorString];
}


@end
